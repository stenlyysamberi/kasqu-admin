<?php $__env->startSection('menu'); ?>

<div class="row">
        <div class="col-12">
            <div class="page-title-box">
            <div class="page-title-right">
            <ol class="breadcrumb m-0">
            <li class="breadcrumb-item"><a href="javascript: void(0);">AJaya</a></li>
            <li class="breadcrumb-item"><a href="javascript: void(0);">Owner</a></li>
            <li class="breadcrumb-item active">Laporan</li>
            </ol>
            </div>
            <h4 class="page-title">Report</h4>
            </div>
        </div>
</div>

<div class="row">
    <div class="col-12">
    <div class="card-box">
    <div class="row">
    <div class="col-lg-8">
    <form  id="form-cari" class="form-inline" action="/report_keluar" method="get">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="inputPassword2" class="sr-only"></label>
            <input id="from"  type="date" name="from" class="form-control" required="required">
        </div>
        <div class="form-group mx-sm-3">
            <label for="status-select" class="mr-2">To</label>
            <input id="to" type="date" name="to" class="form-control" required="required">
        </div>
    
    </div>
        <div class="col-lg-4">
        <div class="text-lg-right mt-3 mt-lg-0">
            <button type="submit" class="btn btn-danger waves-effect waves-light"><i class="mdi-search mr-1"></i>Cari</button>
            
        </div>
        </div><!-- end col-->
    </form>

    </div> <!-- end row -->
    </div> <!-- end card-box -->
    </div> <!-- end col-->
    </div>
    
    
    <div class="row">
    <div class="col-12">
    <div class="card">
    <div class="card-body" >
    <div id="cetak">
    
    
    <center>
        <div class="row">
            <div class="col-12">
                <h3>LAPORAN KEUANGAN DANA KELUAR</h3>
                <h4></h4>
                
            </div>
        </div>
    
    
    </center><br>
    <div class="row">
        <div class="col-lg-12">
    
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">No</th>
                        <th scope="col">Jumlah Keluar</th>
                        <th scope="col">Petugas</th>
                        <th scope="col">Tanggal Bayar</th>
                        <th scope="col">Keterangan</th>
                    </tr>
                </thead>
                <tbody>

                 <?php $__currentLoopData = $dana; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($item->jumlah_keluar); ?></td>
                        <td><?php echo e($item->nama); ?></td>
                        <td><?php echo e($item->created_at); ?></td>
                        <td><?php echo e($item->catatan); ?></td>
                    </tr>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
    
    
        </div>
    
    </div> <!-- end row -->
    </div>
    <!-- action buttons-->
    <div class="row mt-4">
    <div class="col-sm-6">
        <a href="ecommerce-products.html" class="btn text-muted d-none d-sm-inline-block btn-link font-weight-semibold">
    
            <a onclick="printContent('cetak')" href="#" class="btn btn-success"><i class="mdi mdi-printer mr-1"></i> Print </a>
        </a>
    </div> <!-- end col -->
    <div class="col-sm-6">
                                                <!-- <div class="text-sm-right">
                                                    <a href="ecommerce-checkout.html" class="btn btn-danger"><i class="mdi mdi-cart-plus mr-1"></i> Checkout </a>
                                                </div> -->
                                            </div> <!-- end col -->
                                        </div> <!-- end row-->
                                    </div> <!-- end card-body-->
                                </div> <!-- end card-->
                            </div> <!-- end col -->
                        </div>
    
                        <script>
                            function printContent(el){
                              var restorepage = document.body.innerHTML;
                              var printcontent = document.getElementById(el).innerHTML;
                              document.body.innerHTML = printcontent;
                              window.print();
                              document.body.innerHTML = restorepage;
                          }
    
                          function cari_laporan(){
    
                              var data = $('#form-cari').serialize();
                              $.ajax({
                                typo  : 'POST',
                                url   : 'owner/report/tampil.php',
                                data  : data,
                                cache : false,
                                success : function(data){
                                 // $('#tampilkan-laporan').load("owner/report/tampil.php");
                                 $("#tampilkan-laporan").html(data);
                               
    
    
                              }
                          });
    
                          }

                          
    
                      </script>
    
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Stenly\Documents\WebApp\kasqu\admin\resources\views/report_keluar.blade.php ENDPATH**/ ?>